import { IDB_NAME, IDB_VERSION, STORE_META, STORE_SALIDAS } from "./constantes.js";

let dbPromise = null;

export function abrirDB() {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);

    req.onupgradeneeded = () => {
      const db = req.result;

      if (!db.objectStoreNames.contains(STORE_SALIDAS)) {
        const store = db.createObjectStore(STORE_SALIDAS, { keyPath: "docId" });
        store.createIndex("fecha", "fecha", { unique: false });
      }

      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: "key" });
      }
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  return dbPromise;
}

function txStore(db, storeName, mode = "readonly") {
  return db.transaction(storeName, mode).objectStore(storeName);
}

export async function obtenerMeta(key) {
  const db = await abrirDB();
  return new Promise((resolve, reject) => {
    const req = txStore(db, STORE_META).get(key);
    req.onsuccess = () => resolve(req.result?.value || "");
    req.onerror = () => reject(req.error);
  });
}

export async function guardarMeta(key, value) {
  const db = await abrirDB();
  return new Promise((resolve, reject) => {
    const req = txStore(db, STORE_META, "readwrite").put({ key, value });
    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}

export async function guardarSalidas(docs) {
  if (!docs.length) return 0;
  const db = await abrirDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SALIDAS, "readwrite");
    const store = tx.objectStore(STORE_SALIDAS);
    docs.forEach((doc) => store.put(doc));
    tx.oncomplete = () => resolve(docs.length);
    tx.onerror = () => reject(tx.error);
  });
}

export async function obtenerSalidasPorRango(inicio, fin) {
  const db = await abrirDB();

  return new Promise((resolve, reject) => {
    const store = txStore(db, STORE_SALIDAS);
    const idx = store.index("fecha");
    const range = IDBKeyRange.bound(inicio, fin);
    const req = idx.getAll(range);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function limpiarCache() {
  const db = await abrirDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_SALIDAS, STORE_META], "readwrite");
    tx.objectStore(STORE_SALIDAS).clear();
    tx.objectStore(STORE_META).clear();
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}
