import http.server
import socketserver
import webbrowser
from pathlib import Path

PORT = 8000

# Sirve directo la carpeta LISTACIGARRO si existe junto a este server.py.
# Si metes server.py dentro de LISTACIGARRO, sirve esa misma carpeta.
HERE = Path(__file__).resolve().parent
APP_DIR = HERE / "LISTACIGARRO"
BASE_DIR = APP_DIR if (APP_DIR / "index.html").exists() else HERE

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def do_GET(self):
        # Abrir localhost:8000 directo manda a index.html
        if self.path in ("/", ""):
            self.path = "/index.html"
        return super().do_GET()

class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True

if __name__ == "__main__":
    url = f"http://localhost:{PORT}/index.html"
    print("Servidor LISTACIGARRO activo")
    print(f"Carpeta servida: {BASE_DIR}")
    print(f"Abrir: {url}")
    print("CTRL + C para detener")

    with ReusableTCPServer(("", PORT), Handler) as httpd:
        webbrowser.open(url)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServidor detenido.")
