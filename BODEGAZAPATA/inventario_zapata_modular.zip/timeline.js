export function ordenarMovimientosLineaTiempo(movimientos) {
  return [...movimientos].sort((a, b) => {
    if (a.fecha !== b.fecha) return String(a.fecha).localeCompare(String(b.fecha));

    const horaA = String(a.hora || "00:00");
    const horaB = String(b.hora || "00:00");
    if (horaA !== horaB) return horaA.localeCompare(horaB);

    const orden = { ENTRADA: 1, SALIDA: 2, AJUINV: 3 };
    return Number(orden[a.tipo] || 99) - Number(orden[b.tipo] || 99);
  });
}

export function calcularExistenciaLineaTiempo(existenciaInicial, movimientos) {
  let existencia = Number(existenciaInicial || 0);
  const ordenados = ordenarMovimientosLineaTiempo(movimientos);

  for (const mov of ordenados) {
    if (mov.tipo === "ENTRADA") {
      existencia += Number(mov.cantidad || 0);
      continue;
    }

    if (mov.tipo === "SALIDA") {
      existencia -= Number(mov.cantidad || 0);
      continue;
    }

    if (mov.tipo === "AJUINV") {
      existencia = Number(mov.existencia_fisica || 0);
    }
  }

  return existencia;
}

export function movimientoEntrada(item) {
  return {
    tipo: "ENTRADA",
    fecha: item.fecha,
    hora: item.hora || "00:00",
    cantidad: Number(item.cantidad || 0)
  };
}

export function movimientoSalida(item) {
  return {
    tipo: "SALIDA",
    fecha: item.fecha,
    hora: item.hora || "00:00",
    cantidad: Number(item.cantidad || 0)
  };
}

export function movimientoAjuste(item) {
  return {
    tipo: "AJUINV",
    fecha: item.fecha,
    hora: item.hora || "00:00",
    diferencia: Number(item.diferencia || item.cantidad || 0),
    existencia_fisica: Number(item.existencia_fisica || 0),
    existencia_teorica: Number(item.existencia_teorica || 0)
  };
}
