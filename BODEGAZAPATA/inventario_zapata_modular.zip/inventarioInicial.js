import { collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { db } from "./config.js";
import { REF_USUARIOS_INVENTARIO } from "./firestoreRefs.js";
import { CONTEO_ID_INVENTARIO, FECHA_BASE_INVENTARIO } from "./appConfig.js";
import { normalizarCodigo } from "./utils.js";
import { setStatus, setProgress } from "./uiBase.js";

export async function cargarInventarioInicial() {
  const inventario = {};

  setStatus(`Cargando inventario inicial ${CONTEO_ID_INVENTARIO}...`);
  setProgress(8);

  const usuariosSnap = await getDocs(REF_USUARIOS_INVENTARIO);

  let usuariosLeidos = 0;
  let partidasLeidas = 0;

  for (const usuarioDoc of usuariosSnap.docs) {
    usuariosLeidos++;

    const refPartidas = collection(
      db,
      "almacenes",
      "almacen_zapata",
      "Inventarios",
      CONTEO_ID_INVENTARIO,
      "USUARIOS",
      usuarioDoc.id,
      "PARTIDAS"
    );

    const partidasSnap = await getDocs(refPartidas);

    partidasSnap.forEach((docu) => {
      const p = docu.data() || {};

      if (p.eliminado === true) return;

      const codigoOriginal = String(p.codigo || p.productoId || p.codigoOriginal || "").trim();
      const codigoKey = normalizarCodigo(codigoOriginal);
      const nombre = String(p.descripcion || p.nombre || "").trim();
      const cantidad = Number(p.cantidad || 0);

      if (!codigoKey && !nombre && !cantidad) return;

      const key = codigoKey || nombre.toLowerCase();

      if (!inventario[key]) {
        inventario[key] = {
          codigo: codigoOriginal,
          codigoKey,
          nombre,
          inviniOriginal: 0,
          fechaBase: FECHA_BASE_INVENTARIO
        };
      }

      inventario[key].inviniOriginal += cantidad;

      if (!inventario[key].codigo && codigoOriginal) inventario[key].codigo = codigoOriginal;
      if (!inventario[key].nombre && nombre) inventario[key].nombre = nombre;

      partidasLeidas++;
    });
  }

  setStatus(`Inventario inicial cargado. Usuarios: ${usuariosLeidos}. Partidas: ${partidasLeidas}.`);

  return inventario;
}
