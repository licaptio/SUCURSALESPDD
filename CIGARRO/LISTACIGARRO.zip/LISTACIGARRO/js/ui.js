import { $, escapeHtml, fechaCorta, fmtCelda, fmtNum } from "./utils.js";

export function setStatus(msg) {
  const status = $("status");
  if (status) status.textContent = msg;
  const loaderMsg = $("loaderMsg");
  if (loaderMsg) loaderMsg.textContent = msg;
}

export function setProgress(porcentaje) {
  const bar = $("loaderBar");
  if (bar) bar.style.width = Math.max(0, Math.min(100, porcentaje)) + "%";
}

export function ocultarLoader() {
  const loader = $("loader");
  if (loader) loader.classList.add("hide");
}

export function mostrarLoader() {
  const loader = $("loader");
  if (loader) loader.classList.remove("hide");
}

export function getFiltroBusqueda() {
  return String($("busqueda")?.value || "").trim().toLowerCase();
}

export function pasaFiltroPivot(item) {
  const q = getFiltroBusqueda();
  if (!q) return true;
  return [item.codigo, item.nombre].some((v) => String(v || "").toLowerCase().includes(q));
}

export function pasaFiltroDetalle(item) {
  const q = getFiltroBusqueda();
  if (!q) return true;
  return [item.tipo, item.codigo, item.nombre, item.folio, item.destino, item.entrega, item.recibe, item.folioCincho]
    .some((v) => String(v || "").toLowerCase().includes(q));
}

export function pintarPivot({ registrosPivot, fechasColumnas }) {
  const tabla = $("tabla");
  const thead = tabla.querySelector("thead");
  const tbody = tabla.querySelector("tbody");
  const tfoot = tabla.querySelector("tfoot");
  const rows = registrosPivot.filter(pasaFiltroPivot);

  thead.innerHTML = `
    <tr>
      <th class="left sticky-col-1">Código</th>
      <th class="left sticky-col-2">Nombre</th>
      <th>SALIDA<br>ANTERIOR</th>
      ${fechasColumnas.map(f => `<th class="salida-head">${fechaCorta(f)}<br>SALIDA</th>`).join("")}
      <th>SALIDA<br>SEMANA</th>
      <th>TOTAL<br>ACUMULADO</th>
    </tr>
  `;

  tbody.innerHTML = rows.map((r) => `
    <tr>
      <td class="left codigo sticky-col-1">${escapeHtml(r.codigo)}</td>
      <td class="left sticky-col-2">${escapeHtml(r.nombre)}</td>
      <td class="cantidad anterior-col">${fmtCelda(r.salidaAnterior)}</td>
      ${fechasColumnas.map(f => {
        const salida = Number(r.salidasPorFecha[f] || 0);
        return `<td class="salida-col ${salida ? "cantidad" : ""}">${fmtCelda(salida)}</td>`;
      }).join("")}
      <td class="cantidad total-col">${fmtNum(r.totalSemana)}</td>
      <td class="cantidad total-col acumulado-col">${fmtNum(r.totalAcumulado)}</td>
    </tr>
  `).join("");

  const totalSalidasPorFecha = {};
  fechasColumnas.forEach(f => { totalSalidasPorFecha[f] = 0; });

  rows.forEach(r => {
    fechasColumnas.forEach(f => {
      totalSalidasPorFecha[f] += Number(r.salidasPorFecha[f] || 0);
    });
  });

  const totalAnterior = rows.reduce((sum, r) => sum + Number(r.salidaAnterior || 0), 0);
  const totalSemana = rows.reduce((sum, r) => sum + Number(r.totalSemana || 0), 0);
  const totalAcumulado = rows.reduce((sum, r) => sum + Number(r.totalAcumulado || 0), 0);

  tfoot.innerHTML = `
    <tr>
      <td class="left sticky-col-1" colspan="2">TOTAL</td>
      <td>${fmtNum(totalAnterior)}</td>
      ${fechasColumnas.map(f => `<td class="salida-col">${fmtNum(totalSalidasPorFecha[f])}</td>`).join("")}
      <td>${fmtNum(totalSemana)}</td>
      <td>${fmtNum(totalAcumulado)}</td>
    </tr>
  `;
}

export function pintarDetalle(registrosDetalle) {
  const tabla = $("tabla");
  const thead = tabla.querySelector("thead");
  const tbody = tabla.querySelector("tbody");
  const tfoot = tabla.querySelector("tfoot");
  const rows = registrosDetalle.filter(pasaFiltroDetalle);
  const totalSalidas = rows.reduce((sum, x) => sum + Number(x.cantidad || 0), 0);

  thead.innerHTML = `
    <tr>
      <th>Tipo</th>
      <th>Fecha</th>
      <th class="left">Folio</th>
      <th class="left">Destino</th>
      <th class="left">Entrega</th>
      <th class="left">Recibe</th>
      <th>Partida</th>
      <th class="left">Código</th>
      <th class="left">Nombre</th>
      <th>Cantidad</th>
    </tr>
  `;

  tbody.innerHTML = rows.map((r) => `
    <tr>
      <td>${escapeHtml(r.tipo)}</td>
      <td>${escapeHtml(r.fecha)}</td>
      <td class="left">${escapeHtml(r.folio)}</td>
      <td class="left">${escapeHtml(r.destino)}</td>
      <td class="left">${escapeHtml(r.entrega)}</td>
      <td class="left">${escapeHtml(r.recibe)}</td>
      <td>${r.partida}</td>
      <td class="left codigo">${escapeHtml(r.codigo)}</td>
      <td class="left">${escapeHtml(r.nombre)}</td>
      <td class="cantidad">${fmtNum(r.cantidad)}</td>
    </tr>
  `).join("");

  tfoot.innerHTML = `
    <tr>
      <td class="left" colspan="9">TOTAL SALIDAS</td>
      <td>${fmtNum(totalSalidas)}</td>
    </tr>
  `;
}
