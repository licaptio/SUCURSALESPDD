import { fechaCorta } from "./utils.js";
import { pasaFiltroDetalle, pasaFiltroPivot } from "./tablas.js";

export function exportarExcel(estado) {
  const { vistaActual, registrosDetalleMovimientoSemana, registrosPivot, fechasColumnas, rangoSemanaActual } = estado;
  let rows;

  if (vistaActual === "detalle") {
    rows = registrosDetalleMovimientoSemana.filter(pasaFiltroDetalle).map((r) => ({
      Tipo: r.tipo,
      Fecha: r.fecha,
      Hora: r.hora || "",
      Folio: r.folio,
      Destino_Proveedor: r.destino,
      Entrega_Emisor: r.entrega,
      Recibe_Usuario: r.recibe,
      RFC_Emisor: r.rfc_emisor,
      Razon_Social_Emisor: r.razon_social_emisor,
      Alias_Pivot: r.alias_pivot,
      Partida: r.partida,
      Codigo: r.codigo,
      Nombre: r.nombre,
      Cantidad_Diferencia: r.tipo === "AJUINV" ? Number(r.diferencia || 0) : Number(r.cantidad || 0),
      Existencia_Teorica: r.tipo === "AJUINV" ? Number(r.existencia_teorica || 0) : "",
      Existencia_Fisica: r.tipo === "AJUINV" ? Number(r.existencia_fisica || 0) : ""
    }));
  } else {
    rows = registrosPivot.filter(pasaFiltroPivot).map((r) => {
      const obj = {
        Codigo: r.codigo,
        Nombre: r.nombre,
        "INVINI SEMANA": Number(r.inviniSemana || 0)
      };

      fechasColumnas.forEach((f) => {
        obj[`ENTRADA ${fechaCorta(f)}`] = Number(r.entradasPorFecha[f] || 0);
        obj[`SALIDA ${fechaCorta(f)}`] = Number(r.salidasPorFecha[f] || 0);
        obj[`AJUINV ${fechaCorta(f)}`] = Number(r.ajustesPorFecha[f] || 0);
      });

      obj["TOTAL ENTRADAS"] = Number(r.totalEntradasSemana || 0);
      obj["TOTAL SALIDAS"] = Number(r.totalSalidasSemana || 0);
      obj["TOTAL AJUINV"] = Number(r.totalAjustesSemana || 0);
      obj["EXISTENCIA FINAL"] = Number(r.existenciaFinalSemana || 0);

      return obj;
    });
  }

  if (!rows.length) {
    alert("No hay datos para exportar.");
    return;
  }

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);

  XLSX.utils.book_append_sheet(wb, ws, vistaActual === "detalle" ? "Detalle semana" : "Pivot semana");

  XLSX.writeFile(
    wb,
    `movimientos_zapata_${vistaActual}_${rangoSemanaActual.inicio}_a_${rangoSemanaActual.fin}.xlsx`
  );
}
