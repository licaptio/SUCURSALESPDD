import { FECHA_BASE_CONSULTA, META_ULTIMA_FECHA } from "./constantes.js";
import { consultarSalidasFirestore } from "./firestoreSalidas.js";
import { guardarMeta, guardarSalidas, obtenerMeta, obtenerSalidasPorRango } from "./idb.js";
import { sumarDias } from "./utils.js";

export async function asegurarCacheHasta(fin, { forzar = false, onStatus = () => {} } = {}) {
  const ultimaFecha = await obtenerMeta(META_ULTIMA_FECHA);

  let inicioConsulta = FECHA_BASE_CONSULTA;

  if (!forzar && ultimaFecha && ultimaFecha >= fin) {
    onStatus(`Usando cache local IndexedDB. Cache vigente hasta ${ultimaFecha}.`);
    return { consultoFirestore: false, docsDescargados: 0, ultimaFecha };
  }

  if (!forzar && ultimaFecha && ultimaFecha >= FECHA_BASE_CONSULTA) {
    inicioConsulta = sumarDias(ultimaFecha, 1);
  }

  if (inicioConsulta > fin) {
    return { consultoFirestore: false, docsDescargados: 0, ultimaFecha };
  }

  onStatus(`Descargando Firestore ${inicioConsulta} a ${fin}...`);
  const docs = await consultarSalidasFirestore(inicioConsulta, fin);
  await guardarSalidas(docs);
  await guardarMeta(META_ULTIMA_FECHA, fin);

  return { consultoFirestore: true, docsDescargados: docs.length, ultimaFecha: fin };
}

export async function leerSalidasCache(inicio, fin) {
  return obtenerSalidasPorRango(inicio, fin);
}
