import { crearFechasSemana } from "./week.js";
import { calcularExistenciaLineaTiempo, movimientoEntrada, movimientoSalida, movimientoAjuste } from "./timeline.js";

export function asegurarRow(mapa, item) {
  const key = item.codigoKey || String(item.nombre || "").toLowerCase();

  if (!mapa.has(key)) {
    mapa.set(key, {
      codigo: item.codigo,
      codigoKey: item.codigoKey,
      nombre: item.nombre,
      inviniOriginal: 0,
      entradasAcumuladasAnteriores: 0,
      salidasAcumuladasAnteriores: 0,
      ajustesAcumuladosAnteriores: 0,
      inviniSemana: 0,
      entradasPorFecha: {},
      salidasPorFecha: {},
      ajustesPorFecha: {},
      totalEntradasSemana: 0,
      totalSalidasSemana: 0,
      totalAjustesSemana: 0,
      existenciaFinalSemana: 0,
      movimientosAcumuladosAnteriores: [],
      movimientosSemana: []
    });
  }

  const row = mapa.get(key);
  if (!row.codigo && item.codigo) row.codigo = item.codigo;
  if (!row.nombre && item.nombre) row.nombre = item.nombre;
  if (!Array.isArray(row.movimientosAcumuladosAnteriores)) row.movimientosAcumuladosAnteriores = [];
  if (!Array.isArray(row.movimientosSemana)) row.movimientosSemana = [];
  return row;
}

function crearRowInventario(inv) {
  return {
    codigo: inv.codigo,
    codigoKey: inv.codigoKey,
    nombre: inv.nombre,
    inviniOriginal: Number(inv.inviniOriginal || 0),
    entradasAcumuladasAnteriores: 0,
    salidasAcumuladasAnteriores: 0,
    ajustesAcumuladosAnteriores: 0,
    inviniSemana: Number(inv.inviniOriginal || 0),
    entradasPorFecha: {},
    salidasPorFecha: {},
    ajustesPorFecha: {},
    totalEntradasSemana: 0,
    totalSalidasSemana: 0,
    totalAjustesSemana: 0,
    existenciaFinalSemana: Number(inv.inviniOriginal || 0),
    movimientosAcumuladosAnteriores: [],
    movimientosSemana: []
  };
}

export function construirPivot({
  inventarioInicialOriginal,
  detalleSemana,
  detalleAcumuladoAnterior,
  entradasSemana,
  entradasAcumuladoAnterior,
  ajustesSemana,
  ajustesAcumuladoAnterior,
  inicioSemana,
  finSemana
}) {
  const mapa = new Map();
  const fechasColumnas = crearFechasSemana(inicioSemana, finSemana);

  Object.keys(inventarioInicialOriginal).forEach((key) => {
    mapa.set(key, crearRowInventario(inventarioInicialOriginal[key]));
  });

  entradasAcumuladoAnterior.forEach((item) => {
    const row = asegurarRow(mapa, item);
    const cantidad = Number(item.cantidad || 0);
    row.entradasAcumuladasAnteriores += cantidad;
    row.movimientosAcumuladosAnteriores.push(movimientoEntrada(item));
  });

  detalleAcumuladoAnterior.forEach((item) => {
    const row = asegurarRow(mapa, item);
    const cantidad = Number(item.cantidad || 0);
    row.salidasAcumuladasAnteriores += cantidad;
    row.movimientosAcumuladosAnteriores.push(movimientoSalida(item));
  });

  ajustesAcumuladoAnterior.forEach((item) => {
    const row = asegurarRow(mapa, item);
    const diferencia = Number(item.diferencia || item.cantidad || 0);
    row.ajustesAcumuladosAnteriores += diferencia;
    row.movimientosAcumuladosAnteriores.push(movimientoAjuste(item));
  });

  mapa.forEach((row) => {
    row.inviniSemana = calcularExistenciaLineaTiempo(
      Number(row.inviniOriginal || 0),
      row.movimientosAcumuladosAnteriores
    );
    row.existenciaFinalSemana = row.inviniSemana;
  });

  entradasSemana.forEach((item) => {
    const row = asegurarRow(mapa, item);
    const cantidad = Number(item.cantidad || 0);
    row.entradasPorFecha[item.fecha] = Number(row.entradasPorFecha[item.fecha] || 0) + cantidad;
    row.totalEntradasSemana += cantidad;
    row.movimientosSemana.push(movimientoEntrada(item));
  });

  detalleSemana.forEach((item) => {
    const row = asegurarRow(mapa, item);
    const cantidad = Number(item.cantidad || 0);
    row.salidasPorFecha[item.fecha] = Number(row.salidasPorFecha[item.fecha] || 0) + cantidad;
    row.totalSalidasSemana += cantidad;
    row.movimientosSemana.push(movimientoSalida(item));
  });

  ajustesSemana.forEach((item) => {
    const row = asegurarRow(mapa, item);
    const diferencia = Number(item.diferencia || item.cantidad || 0);
    row.ajustesPorFecha[item.fecha] = Number(row.ajustesPorFecha[item.fecha] || 0) + diferencia;
    row.totalAjustesSemana += diferencia;
    row.movimientosSemana.push(movimientoAjuste(item));
  });

  mapa.forEach((row) => {
    row.existenciaFinalSemana = calcularExistenciaLineaTiempo(
      Number(row.inviniSemana || 0),
      row.movimientosSemana
    );
  });

  const registrosPivot = Array.from(mapa.values())
    .sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), "es"));

  return { registrosPivot, fechasColumnas };
}
