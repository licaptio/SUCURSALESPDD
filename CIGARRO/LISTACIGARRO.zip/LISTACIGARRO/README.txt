LISTACIGARRO - PROVSOFT

Ruta Firestore:
/almacenes/almacen_cigarro/salidas1.0

Base de consulta:
01/06/2026

Funcionamiento:
- App modular en carpeta /js.
- Solo maneja SALIDAS.
- Construye tabla pivot con columnas por fecha: DD/MM/AA SALIDA.
- Lee desde 01/06/2026 hasta la fecha fin de la semana seleccionada.
- Guarda documentos descargados en IndexedDB: PROVSOFT_LISTACIGARRO.
- Recargar cache usa IndexedDB y solo descarga fechas faltantes.
- Sincronizar Firestore fuerza descarga desde 01/06/2026 hasta la fecha fin.
- Limpiar cache borra IndexedDB local y vuelve a sincronizar.

Archivo de configuración requerido:
config.js en la raíz de la app, exportando db.

Corrección aplicada:
- La consulta Firestore usa createdAt ISO para filtrar por rango.
- La fecha visible se normaliza desde fecha tipo "9/6/2026, 9:43:37 a.m.".
- Las partidas se leen desde productos[].
