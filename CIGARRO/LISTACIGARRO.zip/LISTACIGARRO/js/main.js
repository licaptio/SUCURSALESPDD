import { FECHA_BASE_CONSULTA } from "./constantes.js";
import { asegurarCacheHasta, leerSalidasCache } from "./cacheService.js";
import { limpiarCache } from "./idb.js";
import { expandirDocumentosADetalle } from "./normalizador.js";
import { construirPivotSalidas } from "./pivot.js";
import { exportarExcel } from "./exportExcel.js";
import { $, obtenerSemanaActualInput, obtenerRangoDomingoSabadoDesdeWeek, sumarDias } from "./utils.js";
import { mostrarLoader, ocultarLoader, pintarDetalle, pintarPivot, setProgress, setStatus } from "./ui.js";

let registrosDetalle = [];
let registrosDetalleAnterior = [];
let registrosDetalleSemana = [];
let registrosPivot = [];
let fechasColumnas = [];
let vistaActual = "resumen";
let rangoActual = {
  base: FECHA_BASE_CONSULTA,
  inicio: FECHA_BASE_CONSULTA,
  fin: FECHA_BASE_CONSULTA,
  anteriorFin: ""
};

function obtenerRango() {
  const selectorSemana = $("selectorSemana");
  const valorWeek = selectorSemana?.value || obtenerSemanaActualInput();

  if (selectorSemana && !selectorSemana.value) {
    selectorSemana.value = valorWeek;
  }

  const rangoSemana = obtenerRangoDomingoSabadoDesdeWeek(valorWeek, FECHA_BASE_CONSULTA);
  const anteriorFin = sumarDias(rangoSemana.inicio, -1);

  rangoActual = {
    base: FECHA_BASE_CONSULTA,
    inicio: rangoSemana.inicio,
    fin: rangoSemana.fin,
    anteriorFin
  };

  if ($("fechaInicio")) $("fechaInicio").value = rangoActual.inicio;
  if ($("fechaFin")) $("fechaFin").value = rangoActual.fin;

  return rangoActual;
}

function pintarTabla() {
  if (vistaActual === "detalle") pintarDetalle(registrosDetalleSemana);
  else pintarPivot({ registrosPivot, fechasColumnas });
}

async function cargarListaCigarro({ forzar = false } = {}) {
  try {
    mostrarLoader();
    setProgress(10);

    const rango = obtenerRango();

    setStatus(`Preparando LISTACIGARRO. Base ${rango.base}. Semana ${rango.inicio} a ${rango.fin}...`);

    const sync = await asegurarCacheHasta(rango.fin, {
      forzar,
      onStatus: setStatus
    });

    setProgress(55);
    setStatus(`Leyendo IndexedDB ${rango.base} a ${rango.fin}...`);

    const docsCache = await leerSalidasCache(rango.base, rango.fin);
    registrosDetalle = expandirDocumentosADetalle(docsCache);

    registrosDetalleAnterior = registrosDetalle.filter(x =>
      x.fecha >= rango.base &&
      rango.anteriorFin >= rango.base &&
      x.fecha <= rango.anteriorFin
    );

    registrosDetalleSemana = registrosDetalle.filter(x =>
      x.fecha >= rango.inicio &&
      x.fecha <= rango.fin
    );

    const pivot = construirPivotSalidas({
      detalleAnterior: registrosDetalleAnterior,
      detalleSemana: registrosDetalleSemana,
      inicioSemana: rango.inicio,
      finSemana: rango.fin
    });

    registrosPivot = pivot.registrosPivot;
    fechasColumnas = pivot.fechasColumnas;

    pintarTabla();

    setProgress(100);

    const totalAnterior = registrosDetalleAnterior.reduce((sum, x) => sum + Number(x.cantidad || 0), 0);
    const totalSemana = registrosDetalleSemana.reduce((sum, x) => sum + Number(x.cantidad || 0), 0);
    const totalAcumulado = totalAnterior + totalSemana;

    const fmt = (n) => Number(n || 0).toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const origen = sync.consultoFirestore
      ? `Firestore descargó ${sync.docsDescargados} documentos y guardó cache.`
      : "Sin consultar Firestore; datos desde cache local.";

    setStatus(`${origen} Semana: ${rango.inicio} a ${rango.fin}. Anterior: ${fmt(totalAnterior)}. Semana: ${fmt(totalSemana)}. Acumulado: ${fmt(totalAcumulado)}. Artículos: ${registrosPivot.length}.`);

    ocultarLoader();
  } catch (error) {
    console.error(error);
    setStatus("Error en LISTACIGARRO: " + error.message);
    ocultarLoader();
  }
}

function cambiarVista(vista) {
  vistaActual = vista;
  $("tabResumen").classList.toggle("active", vista === "resumen");
  $("tabDetalle").classList.toggle("active", vista === "detalle");
  pintarTabla();
}

function inicializarEventos() {
  if ($("selectorSemana")) {
    $("selectorSemana").value = obtenerSemanaActualInput();
    $("selectorSemana").addEventListener("change", () => cargarListaCigarro());
  }

  if ($("fechaInicio")) {
    $("fechaInicio").min = FECHA_BASE_CONSULTA;
    $("fechaInicio").value = FECHA_BASE_CONSULTA;
    $("fechaInicio").readOnly = true;
  }

  if ($("fechaFin")) {
    $("fechaFin").min = FECHA_BASE_CONSULTA;
    $("fechaFin").readOnly = true;
  }

  $("btnConfig")?.addEventListener("click", (ev) => {
    ev.stopPropagation();
    $("menuConfig")?.classList.toggle("oculto");
  });

  document.addEventListener("click", (ev) => {
    const wrap = ev.target.closest?.(".settings-wrap");
    if (!wrap) $("menuConfig")?.classList.add("oculto");
  });

  $("menuConfig")?.addEventListener("click", (ev) => ev.stopPropagation());

  $("btnRecargar")?.addEventListener("click", () => cargarListaCigarro());
  $("btnForzarSync")?.addEventListener("click", () => cargarListaCigarro({ forzar: true }));
  $("btnLimpiarCache")?.addEventListener("click", async () => {
    if (!confirm("¿Limpiar cache local de LISTACIGARRO? La siguiente carga volverá a consultar Firestore.")) return;
    await limpiarCache();
    await cargarListaCigarro({ forzar: true });
  });

  $("btnExportar")?.addEventListener("click", () => exportarExcel({
    vistaActual,
    registrosDetalle: registrosDetalleSemana,
    registrosPivot,
    fechasColumnas,
    rango: rangoActual
  }));

  $("busqueda")?.addEventListener("input", pintarTabla);
  $("tabResumen")?.addEventListener("click", () => cambiarVista("resumen"));
  $("tabDetalle")?.addEventListener("click", () => cambiarVista("detalle"));
}

document.addEventListener("DOMContentLoaded", async () => {
  inicializarEventos();
  await cargarListaCigarro();
});
