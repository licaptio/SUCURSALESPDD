import { collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { db } from "./config.js";
import { REF_AJUSTES_INVENTARIO_ZAPATA } from "./firestoreRefs.js";
import { FECHA_INICIO_MINIMA } from "./appConfig.js";
import { normalizarCodigo, normalizarFecha } from "./utils.js";

export async function consultarAjustesInventario(inicio, fin) {
  if (fin < inicio) return { detalle: [], totalDocs: 0 };

  const snapAjustes = await getDocs(REF_AJUSTES_INVENTARIO_ZAPATA);
  const detalle = [];
  const docsVistos = new Set();

  for (const ajusteDoc of snapAjustes.docs) {
    const ajusteId = ajusteDoc.id;
    const ajusteData = ajusteDoc.data() || {};

    const refPartidas = collection(db, "almacenes", "almacen_zapata", "ajustes_inventario", ajusteId, "PARTIDAS");
    const partidasSnap = await getDocs(refPartidas);

    partidasSnap.forEach((partidaDoc) => {
      const p = partidaDoc.data() || {};
      if (p.eliminado === true) return;

      const fecha = normalizarFecha(
        p.fecha_movimiento || ajusteData.fecha_movimiento || ajusteData.fecha || p.creado_en || ajusteData.creado_en || ""
      );

      if (!fecha || fecha < inicio || fecha > fin) return;
      if (fecha < FECHA_INICIO_MINIMA) return;

      const codigoOriginal = String(p.codigo || p.codigoKey || "").trim();
      const codigoKey = normalizarCodigo(p.codigoKey || codigoOriginal);
      const nombre = String(p.nombre || p.descripcion || "").trim();

      const diferencia = Number(p.diferencia || 0);
      const existenciaFisica = Number(p.existencia_fisica || 0);
      const existenciaTeorica = Number(p.existencia_teorica || 0);

      if (!codigoKey && !nombre && !diferencia) return;

      docsVistos.add(ajusteId);

      const fechaDDMMYY = fecha.replaceAll("-", "").substring(2);
      const folioAju = String(ajusteData.folio || ajusteId || "").trim();

      detalle.push({
        tipo: "AJUINV",
        docId: ajusteId,
        partida: p.partida || partidaDoc.id || "",
        folio: folioAju || `AJUINV-${fechaDDMMYY}`,
        fecha,
        hora: String(p.hora_movimiento || ajusteData.hora_movimiento || "00:00").trim(),
        destino: "AJUSTE INVENTARIO",
        entrega: "AJUINV",
        recibe: String(ajusteData.usuario || ajusteData.usuario_nombre || "").trim(),
        folioCincho: "",
        proveedor: "",
        alias_pivot: "",
        rfc_emisor: "",
        razon_social_emisor: "",
        codigo: codigoOriginal,
        codigoKey,
        nombre,
        cantidad: diferencia,
        diferencia,
        existencia_fisica: existenciaFisica,
        existencia_teorica: existenciaTeorica
      });
    });
  }

  return { detalle, totalDocs: docsVistos.size };
}
