import { db } from "./config.js";
import { collection } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { CONTEO_ID_INVENTARIO } from "./appConfig.js";

export const REF_SALIDAS_ZAPATA = collection(db, "almacenes", "almacen_zapata", "salidas1.0");
export const REF_ENTRADAS_ZAPATA = collection(db, "almacenes", "almacen_zapata", "entradas");
export const REF_AJUSTES_INVENTARIO_ZAPATA = collection(db, "almacenes", "almacen_zapata", "ajustes_inventario");
export const REF_PROVEEDORES_AUTORIZADOS_ZAPATA = collection(db, "almacenes", "almacen_zapata", "configuracion", "proveedores_autorizados", "items");
export const REF_USUARIOS_INVENTARIO = collection(db, "almacenes", "almacen_zapata", "Inventarios", CONTEO_ID_INVENTARIO, "USUARIOS");
