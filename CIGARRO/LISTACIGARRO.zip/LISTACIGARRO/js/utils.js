export const $ = (id) => document.getElementById(id);

export function fechaISOLocal(date) {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export function hoyISO() {
  return fechaISOLocal(new Date());
}

export function crearFechaLocal(fechaISO) {
  const [yyyy, mm, dd] = String(fechaISO).split("-").map(Number);
  return new Date(yyyy, mm - 1, dd);
}

export function sumarDias(fechaISO, dias) {
  const d = crearFechaLocal(fechaISO);
  d.setDate(d.getDate() + dias);
  return fechaISOLocal(d);
}

export function inicioDiaISO(fechaISO) {
  return `${fechaISO}T00:00:00.000Z`;
}

export function finDiaISO(fechaISO) {
  return `${fechaISO}T23:59:59.999Z`;
}

export function normalizarFecha(valor) {
  if (!valor) return "";

  if (typeof valor === "string") {
    const v = valor.trim();

    // Firestore mostrado como texto: 9/6/2026, 9:43:37 a.m.
    const m0 = v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:,.*)?$/);
    if (m0) {
      const [, d, m, yyyy] = m0;
      const dd = String(d).padStart(2, "0");
      const mm = String(m).padStart(2, "0");
      return `${yyyy}-${mm}-${dd}`;
    }

    const m1 = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (m1) {
      const [, dd, mm, yyyy] = m1;
      return `${yyyy}-${mm}-${dd}`;
    }

    const m2 = v.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m2) return `${m2[1]}-${m2[2]}-${m2[3]}`;

    return v.substring(0, 10);
  }

  if (valor && typeof valor.toDate === "function") return fechaISOLocal(valor.toDate());
  if (valor && typeof valor.seconds === "number") return fechaISOLocal(new Date(valor.seconds * 1000));
  return String(valor).trim();
}

export function fechaCorta(fechaISO) {
  if (!fechaISO || !fechaISO.includes("-")) return fechaISO || "";
  const [yyyy, mm, dd] = fechaISO.split("-");
  return `${dd}/${mm}/${String(yyyy).slice(-2)}`;
}

export function normalizarCodigo(valor) {
  const s = String(valor ?? "").trim();
  if (!s) return "";
  const soloDigitos = s.replace(/\D/g, "");
  if (!soloDigitos) return s.toLowerCase();
  return soloDigitos.replace(/^0+/, "") || "0";
}

export function escapeHtml(text) {
  return String(text ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export function fmtNum(n) {
  return Number(n || 0).toLocaleString("es-MX", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

export function fmtCelda(n) {
  const num = Number(n || 0);
  if (!num) return "";
  return fmtNum(num);
}

export function obtenerSemanaActualInput() {
  const hoy = new Date();
  const fecha = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
  const dia = fecha.getDay();
  const jueves = new Date(fecha);
  jueves.setDate(fecha.getDate() + (4 - (dia || 7)));
  const inicioAnio = new Date(jueves.getFullYear(), 0, 1);
  const semana = Math.ceil((((jueves - inicioAnio) / 86400000) + 1) / 7);
  return `${jueves.getFullYear()}-W${String(semana).padStart(2, "0")}`;
}

export function obtenerRangoDomingoSabadoDesdeWeek(valorWeek, fechaBase) {
  if (!valorWeek) return { inicio: fechaBase, fin: sumarDias(fechaBase, 6) };

  const [anioTexto, semanaTexto] = valorWeek.split("-W");
  const anio = Number(anioTexto);
  const semana = Number(semanaTexto);
  const enero4 = new Date(anio, 0, 4);
  const diaSemana = enero4.getDay() || 7;
  const lunesSemana1 = new Date(enero4);
  lunesSemana1.setDate(enero4.getDate() - diaSemana + 1);
  const lunes = new Date(lunesSemana1);
  lunes.setDate(lunesSemana1.getDate() + (semana - 1) * 7);
  const domingo = new Date(lunes);
  domingo.setDate(lunes.getDate() - 1);
  const sabado = new Date(domingo);
  sabado.setDate(domingo.getDate() + 6);

  let inicio = fechaISOLocal(domingo);
  let fin = fechaISOLocal(sabado);

  if (inicio < fechaBase) inicio = fechaBase;
  if (fin < inicio) fin = inicio;

  return { inicio, fin };
}

export function crearFechas(inicio, fin) {
  const fechas = [];
  let actual = inicio;
  while (actual <= fin) {
    fechas.push(actual);
    actual = sumarDias(actual, 1);
  }
  return fechas;
}
