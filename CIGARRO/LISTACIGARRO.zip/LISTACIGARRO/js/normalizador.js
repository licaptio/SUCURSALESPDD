import { normalizarCodigo } from "./utils.js";

export function expandirDocumentosADetalle(docs) {
  const detalle = [];

  docs.forEach((data) => {
    const articulos = Array.isArray(data.articulos) ? data.articulos : [];

    articulos.forEach((art, idx) => {
      const codigoOriginal = String(art.codigo ?? art.codigo_interno ?? art.productoId ?? "").trim();
      const codigoKey = normalizarCodigo(codigoOriginal);
      const nombre = String(
        art.nombre ??
        art.descripcion ??
        art.descripcion_interna ??
        art.descripcion_factura ??
        ""
      ).trim();
      const cantidad = Number(art.cantidad ?? art.cantidad_salida ?? art.piezas ?? 0);

      if (!codigoKey && !nombre && !cantidad) return;

      detalle.push({
        tipo: "SALIDA",
        docId: data.docId,
        partida: idx + 1,
        folio: data.folio || data.docId || "",
        fecha: data.fecha,
        destino: data.destino || "",
        entrega: data.entrega || "",
        recibe: data.recibe || "",
        folioCincho: data.folioCincho || "",
        codigo: codigoOriginal,
        codigoKey,
        nombre,
        cantidad
      });
    });
  });

  return detalle.sort((a, b) => {
    if (a.fecha !== b.fecha) return String(b.fecha).localeCompare(String(a.fecha));
    return String(a.nombre).localeCompare(String(b.nombre), "es");
  });
}
