import { $, escapeHtml, fechaCorta, fmtCelda, fmtNum } from "./utils.js";

export function getFiltroBusqueda() {
  return String($("busqueda")?.value || "").trim().toLowerCase();
}

export function pasaFiltroPivot(item) {
  const q = getFiltroBusqueda();
  if (!q) return true;
  return [item.codigo, item.nombre].some((v) => String(v || "").toLowerCase().includes(q));
}

export function pasaFiltroDetalle(item) {
  const q = getFiltroBusqueda();
  if (!q) return true;

  return [
    item.tipo,
    item.codigo,
    item.nombre,
    item.folio,
    item.destino,
    item.entrega,
    item.recibe,
    item.proveedor,
    item.alias_pivot,
    item.rfc_emisor,
    item.razon_social_emisor
  ].some((v) => String(v || "").toLowerCase().includes(q));
}

export function obtenerProveedoresEntradaPorFecha(fecha, registrosEntradasSemana) {
  const proveedores = registrosEntradasSemana
    .filter(x => x.fecha === fecha)
    .map(x => String(x.alias_pivot || x.proveedor || x.entrega || "").trim())
    .filter(Boolean);

  return [...new Set(proveedores)].join(" / ");
}

export function obtenerFoliosAjustePorFecha(fecha, registrosAjustesSemana) {
  const folios = registrosAjustesSemana
    .filter(x => x.fecha === fecha)
    .map(x => String(x.folio || "").trim())
    .filter(Boolean);

  return [...new Set(folios)].join(" / ");
}

export function pintarTabla(estado) {
  if (estado.vistaActual === "detalle") pintarDetalle(estado);
  else pintarPivotPorSemana(estado);
}

export function pintarPivotPorSemana(estado) {
  const { registrosPivot, fechasColumnas, registrosEntradasSemana, registrosAjustesSemana } = estado;
  const tabla = $("tabla");
  const thead = tabla.querySelector("thead");
  const tbody = tabla.querySelector("tbody");
  const tfoot = tabla.querySelector("tfoot");

  const rows = registrosPivot.filter(pasaFiltroPivot);

  const fechasConEntrada = fechasColumnas.filter(f => registrosEntradasSemana.some(x => x.fecha === f));
  const fechasConAjuste = fechasColumnas.filter(f => registrosAjustesSemana.some(x => x.fecha === f));

  thead.innerHTML = `
    <tr>
      <th class="left">Código</th>
      <th class="left">Nombre</th>
      <th>INVINI<br>SEMANA</th>

      ${fechasColumnas.map(f => {
        const proveedor = obtenerProveedoresEntradaPorFecha(f, registrosEntradasSemana);
        const foliosAjuste = obtenerFoliosAjustePorFecha(f, registrosAjustesSemana);
        const tieneEntrada = fechasConEntrada.includes(f);
        const tieneAjuste = fechasConAjuste.includes(f);

        return `
          ${tieneEntrada ? `<th class="entrada-head">${fechaCorta(f)}<br>ENTRADA<br><small>${escapeHtml(proveedor)}</small></th>` : ""}
          <th class="salida-head">${fechaCorta(f)}<br>SALIDA</th>
          ${tieneAjuste ? `<th class="ajuste-head">${fechaCorta(f)}<br>AJUINV<br><small>${escapeHtml(foliosAjuste || "AJUSTE")}</small></th>` : ""}
        `;
      }).join("")}

      <th>TOTAL<br>ENTRADAS</th>
      <th>TOTAL<br>SALIDAS</th>
      <th>TOTAL<br>AJUINV</th>
      <th>EXISTENCIA<br>FINAL</th>
    </tr>
  `;

  tbody.innerHTML = rows.map((r) => `
    <tr>
      <td class="left codigo">${escapeHtml(r.codigo)}</td>
      <td class="left">${escapeHtml(r.nombre)}</td>
      <td class="cantidad">${fmtNum(r.inviniSemana)}</td>

      ${fechasColumnas.map(f => {
        const entrada = Number(r.entradasPorFecha[f] || 0);
        const salida = Number(r.salidasPorFecha[f] || 0);
        const ajuste = Number(r.ajustesPorFecha[f] || 0);
        const tieneEntrada = fechasConEntrada.includes(f);
        const tieneAjuste = fechasConAjuste.includes(f);

        return `
          ${tieneEntrada ? `<td class="entrada-col ${entrada ? "cantidad" : ""}">${fmtCelda(entrada)}</td>` : ""}
          <td class="salida-col ${salida ? "cantidad" : ""}">${fmtCelda(salida)}</td>
          ${tieneAjuste ? `<td class="ajuste-col ${ajuste ? "cantidad" : ""}">${fmtCelda(ajuste)}</td>` : ""}
        `;
      }).join("")}

      <td class="cantidad entrada-total">${fmtNum(r.totalEntradasSemana)}</td>
      <td class="cantidad">${fmtNum(r.totalSalidasSemana)}</td>
      <td class="cantidad">${fmtNum(r.totalAjustesSemana)}</td>
      <td class="cantidad">${fmtNum(r.existenciaFinalSemana)}</td>
    </tr>
  `).join("");

  const totalEntradasPorFecha = {};
  const totalSalidasPorFecha = {};
  const totalAjustesPorFecha = {};

  fechasColumnas.forEach(f => {
    totalEntradasPorFecha[f] = 0;
    totalSalidasPorFecha[f] = 0;
    totalAjustesPorFecha[f] = 0;
  });

  rows.forEach(r => {
    fechasColumnas.forEach(f => {
      totalEntradasPorFecha[f] += Number(r.entradasPorFecha[f] || 0);
      totalSalidasPorFecha[f] += Number(r.salidasPorFecha[f] || 0);
      totalAjustesPorFecha[f] += Number(r.ajustesPorFecha[f] || 0);
    });
  });

  const totalInviniSemana = rows.reduce((sum, r) => sum + Number(r.inviniSemana || 0), 0);
  const totalEntradasSemana = rows.reduce((sum, r) => sum + Number(r.totalEntradasSemana || 0), 0);
  const totalSalidasSemana = rows.reduce((sum, r) => sum + Number(r.totalSalidasSemana || 0), 0);
  const totalAjustesSemana = rows.reduce((sum, r) => sum + Number(r.totalAjustesSemana || 0), 0);
  const totalExistenciaFinal = rows.reduce((sum, r) => sum + Number(r.existenciaFinalSemana || 0), 0);

  tfoot.innerHTML = `
    <tr>
      <td class="left" colspan="2">TOTAL</td>
      <td>${fmtNum(totalInviniSemana)}</td>
      ${fechasColumnas.map(f => {
        const tieneEntrada = fechasConEntrada.includes(f);
        const tieneAjuste = fechasConAjuste.includes(f);
        return `
          ${tieneEntrada ? `<td class="entrada-col">${fmtNum(totalEntradasPorFecha[f])}</td>` : ""}
          <td class="salida-col">${fmtNum(totalSalidasPorFecha[f])}</td>
          ${tieneAjuste ? `<td class="ajuste-col">${fmtNum(totalAjustesPorFecha[f])}</td>` : ""}
        `;
      }).join("")}
      <td>${fmtNum(totalEntradasSemana)}</td>
      <td>${fmtNum(totalSalidasSemana)}</td>
      <td>${fmtNum(totalAjustesSemana)}</td>
      <td>${fmtNum(totalExistenciaFinal)}</td>
    </tr>
  `;
}

export function pintarDetalle(estado) {
  const { registrosDetalleMovimientoSemana } = estado;
  const tabla = $("tabla");
  const thead = tabla.querySelector("thead");
  const tbody = tabla.querySelector("tbody");
  const tfoot = tabla.querySelector("tfoot");

  const rows = registrosDetalleMovimientoSemana.filter(pasaFiltroDetalle);

  const totalEntradas = rows.filter(x => x.tipo === "ENTRADA").reduce((sum, x) => sum + Number(x.cantidad || 0), 0);
  const totalSalidas = rows.filter(x => x.tipo === "SALIDA").reduce((sum, x) => sum + Number(x.cantidad || 0), 0);
  const totalAjustes = rows.filter(x => x.tipo === "AJUINV").reduce((sum, x) => sum + Number(x.diferencia || x.cantidad || 0), 0);

  thead.innerHTML = `
    <tr>
      <th>Tipo</th>
      <th>Fecha</th>
      <th>Hora</th>
      <th class="left">Folio</th>
      <th class="left">Destino / Proveedor</th>
      <th class="left">Entrega / Emisor</th>
      <th class="left">Recibe / Usuario</th>
      <th>Partida</th>
      <th class="left">Código</th>
      <th class="left">Nombre</th>
      <th>Cantidad / Diferencia</th>
      <th>Teórica</th>
      <th>Física</th>
    </tr>
  `;

  tbody.innerHTML = rows.map((r) => `
    <tr>
      <td>${escapeHtml(r.tipo)}</td>
      <td>${escapeHtml(r.fecha)}</td>
      <td>${escapeHtml(r.hora || "")}</td>
      <td class="left">${escapeHtml(r.folio)}</td>
      <td class="left">${escapeHtml(r.destino)}</td>
      <td class="left">${escapeHtml(r.entrega)}</td>
      <td class="left">${escapeHtml(r.recibe)}</td>
      <td>${escapeHtml(r.partida)}</td>
      <td class="left codigo">${escapeHtml(r.codigo)}</td>
      <td class="left">${escapeHtml(r.nombre)}</td>
      <td class="cantidad">${fmtNum(r.tipo === "AJUINV" ? r.diferencia : r.cantidad)}</td>
      <td class="cantidad">${r.tipo === "AJUINV" ? fmtNum(r.existencia_teorica) : ""}</td>
      <td class="cantidad">${r.tipo === "AJUINV" ? fmtNum(r.existencia_fisica) : ""}</td>
    </tr>
  `).join("");

  tfoot.innerHTML = `
    <tr><td class="left" colspan="12">TOTAL ENTRADAS SEMANA</td><td>${fmtNum(totalEntradas)}</td></tr>
    <tr><td class="left" colspan="12">TOTAL SALIDAS SEMANA</td><td>${fmtNum(totalSalidas)}</td></tr>
    <tr><td class="left" colspan="12">TOTAL AJUINV SEMANA</td><td>${fmtNum(totalAjustes)}</td></tr>
  `;
}
