import { FECHA_BASE_INVENTARIO, FECHA_INICIO_MINIMA } from "./appConfig.js";
import { $, hoyISO, sumarDias, fechaCorta, fmtNum } from "./utils.js";
import {
  setStatus,
  setProgress,
  ocultarLoader,
  obtenerSemanaActualInput,
  obtenerRangoDomingoSabadoDesdeWeek,
  crearSelectorSemanaSiNoExiste
} from "./uiBase.js";
import { cargarInventarioInicial } from "./inventarioInicial.js";
import { cargarProveedoresAutorizadosPivot } from "./proveedores.js";
import { consultarSalidas } from "./salidas.js";
import { consultarEntradas } from "./entradas.js";
import { consultarAjustesInventario } from "./ajustes.js";
import { construirPivot } from "./pivot.js";
import { pintarTabla } from "./tablas.js";
import { exportarExcel } from "./excel.js";

const estado = {
  registrosDetalleSemana: [],
  registrosDetalleAcumuladoAnterior: [],
  registrosEntradasSemana: [],
  registrosEntradasAcumuladoAnterior: [],
  registrosAjustesSemana: [],
  registrosAjustesAcumuladoAnterior: [],
  registrosDetalleMovimientoSemana: [],
  registrosPivot: [],
  fechasColumnas: [],
  inventarioInicialOriginal: {},
  vistaActual: "resumen",
  rangoSemanaActual: {
    inicio: FECHA_BASE_INVENTARIO,
    fin: FECHA_BASE_INVENTARIO,
    acumuladoAnteriorFin: ""
  }
};

function obtenerRangoSemana() {
  const selectorSemana = $("selectorSemana");
  const valorWeek = selectorSemana?.value || obtenerSemanaActualInput();

  if (selectorSemana && !selectorSemana.value) selectorSemana.value = valorWeek;

  const rango = obtenerRangoDomingoSabadoDesdeWeek(valorWeek);
  const acumuladoAnteriorFin = sumarDias(rango.inicio, -1);

  estado.rangoSemanaActual = {
    inicio: rango.inicio,
    fin: rango.fin,
    acumuladoAnteriorFin
  };

  if ($("fechaInicio")) $("fechaInicio").value = rango.inicio;
  if ($("fechaFin")) $("fechaFin").value = rango.fin;

  return estado.rangoSemanaActual;
}

function ordenarDetalleMovimientoSemana() {
  estado.registrosDetalleMovimientoSemana = [
    ...estado.registrosEntradasSemana,
    ...estado.registrosDetalleSemana,
    ...estado.registrosAjustesSemana
  ].sort((a, b) => {
    if (a.fecha !== b.fecha) return String(b.fecha).localeCompare(String(a.fecha));
    if (String(a.hora || "") !== String(b.hora || "")) {
      return String(b.hora || "").localeCompare(String(a.hora || ""));
    }
    return String(a.tipo).localeCompare(String(b.tipo));
  });
}

function actualizarResumenSuperior(totalDocsSemana, totalDocsEntradasSemana, totalDocsAjustesSemana) {
  const totalCantidadSalidasSemana = estado.registrosDetalleSemana.reduce(
    (sum, x) => sum + Number(x.cantidad || 0),
    0
  );

  const totalCantidadEntradasSemana = estado.registrosEntradasSemana.reduce(
    (sum, x) => sum + Number(x.cantidad || 0),
    0
  );

  const totalCantidadAjustesSemana = estado.registrosAjustesSemana.reduce(
    (sum, x) => sum + Number(x.diferencia || x.cantidad || 0),
    0
  );

  if ($("totalDocs")) {
    $("totalDocs").textContent =
      Number(totalDocsSemana || 0) +
      Number(totalDocsEntradasSemana || 0) +
      Number(totalDocsAjustesSemana || 0);
  }

  if ($("totalPartidas")) $("totalPartidas").textContent = estado.registrosDetalleMovimientoSemana.length;

  if ($("totalCantidad")) {
    $("totalCantidad").textContent =
      `E ${fmtNum(totalCantidadEntradasSemana)} / S ${fmtNum(totalCantidadSalidasSemana)} / AJU ${fmtNum(totalCantidadAjustesSemana)}`;
  }

  if ($("totalCodigos")) $("totalCodigos").textContent = estado.registrosPivot.length;
}

async function cargarSalidasZapata() {
  try {
    const rango = obtenerRangoSemana();

    estado.inventarioInicialOriginal = await cargarInventarioInicial();
    await cargarProveedoresAutorizadosPivot();

    setStatus(`Consultando semana ${rango.inicio} a ${rango.fin}. Acumulado anterior hasta ${rango.acumuladoAnteriorFin}...`);
    setProgress(25);

    const consultaSemana = await consultarSalidas(rango.inicio, rango.fin);
    const consultaEntradasSemana = await consultarEntradas(rango.inicio, rango.fin);
    const consultaAjustesSemana = await consultarAjustesInventario(rango.inicio, rango.fin);

    setProgress(55);

    let consultaAcumuladoAnterior = { detalle: [], totalDocs: 0 };
    let consultaEntradasAcumuladoAnterior = { detalle: [], totalDocs: 0 };
    let consultaAjustesAcumuladoAnterior = { detalle: [], totalDocs: 0 };

    if (rango.acumuladoAnteriorFin >= FECHA_BASE_INVENTARIO) {
      consultaAcumuladoAnterior = await consultarSalidas(FECHA_BASE_INVENTARIO, rango.acumuladoAnteriorFin);
      consultaEntradasAcumuladoAnterior = await consultarEntradas(FECHA_BASE_INVENTARIO, rango.acumuladoAnteriorFin);
      consultaAjustesAcumuladoAnterior = await consultarAjustesInventario(FECHA_BASE_INVENTARIO, rango.acumuladoAnteriorFin);
    }

    setProgress(75);

    estado.registrosDetalleSemana = consultaSemana.detalle;
    estado.registrosDetalleAcumuladoAnterior = consultaAcumuladoAnterior.detalle;
    estado.registrosEntradasSemana = consultaEntradasSemana.detalle;
    estado.registrosEntradasAcumuladoAnterior = consultaEntradasAcumuladoAnterior.detalle;
    estado.registrosAjustesSemana = consultaAjustesSemana.detalle;
    estado.registrosAjustesAcumuladoAnterior = consultaAjustesAcumuladoAnterior.detalle;

    ordenarDetalleMovimientoSemana();

    const pivot = construirPivot({
      inventarioInicialOriginal: estado.inventarioInicialOriginal,
      detalleSemana: estado.registrosDetalleSemana,
      detalleAcumuladoAnterior: estado.registrosDetalleAcumuladoAnterior,
      entradasSemana: estado.registrosEntradasSemana,
      entradasAcumuladoAnterior: estado.registrosEntradasAcumuladoAnterior,
      ajustesSemana: estado.registrosAjustesSemana,
      ajustesAcumuladoAnterior: estado.registrosAjustesAcumuladoAnterior,
      inicioSemana: rango.inicio,
      finSemana: rango.fin
    });

    estado.registrosPivot = pivot.registrosPivot;
    estado.fechasColumnas = pivot.fechasColumnas;

    actualizarResumenSuperior(
      consultaSemana.totalDocs,
      consultaEntradasSemana.totalDocs,
      consultaAjustesSemana.totalDocs
    );

    pintarTabla(estado);

    setProgress(100);
    setStatus(
      `Consulta lista. Semana: ${fechaCorta(rango.inicio)} a ${fechaCorta(rango.fin)}. Entradas: ${estado.registrosEntradasSemana.length}. Salidas: ${estado.registrosDetalleSemana.length}. Ajustes: ${estado.registrosAjustesSemana.length}.`
    );

    ocultarLoader();
  } catch (error) {
    console.error(error);
    setStatus("Error al cargar movimientos Zapata: " + error.message);
    ocultarLoader();
  }
}

function cambiarVista(vista) {
  estado.vistaActual = vista;

  $("tabResumen").classList.toggle("active", vista === "resumen");
  $("tabDetalle").classList.toggle("active", vista === "detalle");

  pintarTabla(estado);
}

function inicializarEventos() {
  crearSelectorSemanaSiNoExiste();

  if ($("selectorSemana")) {
    $("selectorSemana").value = obtenerSemanaActualInput();
    $("selectorSemana").addEventListener("change", cargarSalidasZapata);
  }

  if ($("fechaInicio")) {
    $("fechaInicio").min = FECHA_INICIO_MINIMA;
    $("fechaInicio").value = FECHA_INICIO_MINIMA;
    $("fechaInicio").readOnly = true;
  }

  if ($("fechaFin")) {
    $("fechaFin").value = hoyISO();
    $("fechaFin").readOnly = true;
  }

  $("btnRecargar").addEventListener("click", cargarSalidasZapata);
  $("btnExportar").addEventListener("click", () => exportarExcel(estado));
  $("busqueda").addEventListener("input", () => pintarTabla(estado));

  $("tabResumen").textContent = "Pivot semanal";
  $("tabResumen").addEventListener("click", () => cambiarVista("resumen"));

  $("tabDetalle").textContent = "Detalle semana";
  $("tabDetalle").addEventListener("click", () => cambiarVista("detalle"));
}

document.addEventListener("DOMContentLoaded", async () => {
  inicializarEventos();
  await cargarSalidasZapata();
});
