import { db } from "../config.js";
import { collection, query, where, orderBy, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { finDiaISO, inicioDiaISO, normalizarFecha } from "./utils.js";

// Ruta correcta:
// /almacenes/almacen_cigarro/salidas1.0/{documento}
const REF_SALIDAS_CIGARRO = collection(db, "almacenes", "almacen_cigarro", "salidas1.0");

export async function consultarSalidasFirestore(inicio, fin) {
  if (fin < inicio) return [];

  // IMPORTANTE:
  // No filtramos por "fecha" porque viene como texto tipo: "9/6/2026, 9:43:37 a.m."
  // Filtramos por createdAt ISO: "2026-06-09T16:27:15.770Z"
  const q = query(
    REF_SALIDAS_CIGARRO,
    where("createdAt", ">=", inicioDiaISO(inicio)),
    where("createdAt", "<=", finDiaISO(fin)),
    orderBy("createdAt", "asc")
  );

  const snap = await getDocs(q);
  const docs = [];

  snap.forEach((documento) => {
    const data = documento.data() || {};
    const fecha = normalizarFecha(data.fecha || data.createdAt || data.timestamp || "");
    if (!fecha || fecha < inicio || fecha > fin) return;

    docs.push({
      docId: documento.id,
      fecha,
      createdAt: String(data.createdAt || ""),
      folio: String(data.folio || documento.id || "").trim(),
      destino: String(data.destino || data.sucursal || "").trim(),
      entrega: String(data.entrega || data.entrego || data.usuario || "").trim(),
      recibe: String(data.recibe || data.recibio || "").trim(),
      folioCincho: String(data.folioCincho || "").trim(),
      articulos: Array.isArray(data.productos)
        ? data.productos
        : Array.isArray(data.articulos)
          ? data.articulos
          : Array.isArray(data.partidas)
            ? data.partidas
            : [],
      cacheActualizadoEn: new Date().toISOString()
    });
  });

  return docs;
}
