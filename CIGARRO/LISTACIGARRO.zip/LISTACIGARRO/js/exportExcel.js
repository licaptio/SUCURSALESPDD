import { fechaCorta } from "./utils.js";
import { pasaFiltroDetalle, pasaFiltroPivot } from "./ui.js";

export function exportarExcel({ vistaActual, registrosDetalle, registrosPivot, fechasColumnas, rango }) {
  let rows;

  if (vistaActual === "detalle") {
    rows = registrosDetalle.filter(pasaFiltroDetalle).map((r) => ({
      Tipo: r.tipo,
      Fecha: r.fecha,
      Folio: r.folio,
      Destino: r.destino,
      Entrega: r.entrega,
      Recibe: r.recibe,
      Partida: r.partida,
      Codigo: r.codigo,
      Nombre: r.nombre,
      Cantidad: r.cantidad
    }));
  } else {
    rows = registrosPivot.filter(pasaFiltroPivot).map((r) => {
      const obj = {
        Codigo: r.codigo,
        Nombre: r.nombre,
        "SALIDA ANTERIOR": Number(r.salidaAnterior || 0)
      };
      fechasColumnas.forEach((f) => {
        obj[`${fechaCorta(f)} SALIDA`] = Number(r.salidasPorFecha[f] || 0);
      });
      obj["SALIDA SEMANA"] = Number(r.totalSemana || 0);
      obj["TOTAL ACUMULADO"] = Number(r.totalAcumulado || 0);
      return obj;
    });
  }

  if (!rows.length) {
    alert("No hay datos para exportar.");
    return;
  }

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, vistaActual === "detalle" ? "Detalle salidas" : "Pivot salidas");
  XLSX.writeFile(wb, `LISTACIGARRO_${vistaActual}_${rango.inicio}_a_${rango.fin}.xlsx`);
}
