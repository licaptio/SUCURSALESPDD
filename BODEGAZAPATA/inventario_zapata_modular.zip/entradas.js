import { query, where, orderBy, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { REF_ENTRADAS_ZAPATA } from "./firestoreRefs.js";
import { FECHA_INICIO_MINIMA } from "./appConfig.js";
import { normalizarCodigo, normalizarFecha } from "./utils.js";
import { obtenerAliasProveedorPivot } from "./proveedores.js";

export async function consultarEntradas(inicio, fin) {
  if (fin < inicio) return { detalle: [], totalDocs: 0 };

  const q = query(
    REF_ENTRADAS_ZAPATA,
    where("fecha", ">=", inicio),
    where("fecha", "<=", fin),
    orderBy("fecha", "desc")
  );

  const snap = await getDocs(q);
  const detalle = [];
  const docsVistos = new Set();

  snap.forEach((documento) => {
    const data = documento.data() || {};
    docsVistos.add(documento.id);

    if (data.estado_zapata && data.estado_zapata !== "ENTRADA_GENERADA") return;

    const fecha = normalizarFecha(data.fecha || data.fecha_factura || data.creado_en || data.timestamp || "");
    if (!fecha || fecha < FECHA_INICIO_MINIMA) return;

    const rfcEmisor = String(data.rfc_emisor || "").trim().toUpperCase();
    const razonSocialEmisor = String(data.razon_social_emisor || "").trim();
    const aliasPivot = obtenerAliasProveedorPivot(rfcEmisor, razonSocialEmisor);

    const articulos = Array.isArray(data.articulos) ? data.articulos : [];

    articulos.forEach((art, idx) => {
      const codigoOriginal = String(art.codigo_interno || "").trim();
      const codigoKey = normalizarCodigo(codigoOriginal);
      const nombre = String(art.descripcion_interna || art.descripcion_factura || "").trim();
      const cantidad = Number(art.cantidad_entrada || 0);

      if (!codigoKey && !nombre && !cantidad) return;

      detalle.push({
        tipo: "ENTRADA",
        docId: documento.id,
        partida: idx + 1,
        folio: String(data.folioEntrada || data.folio || documento.id || "").trim(),
        fecha,
        hora: String(data.hora || data.hora_movimiento || "00:00").trim(),
        destino: "ALMACÉN ZAPATA",
        entrega: aliasPivot,
        recibe: String(data.usuario || "").trim(),
        folioCincho: "",
        proveedor: aliasPivot,
        rfc_emisor: rfcEmisor,
        razon_social_emisor: razonSocialEmisor,
        alias_pivot: aliasPivot,
        codigo: codigoOriginal,
        codigoKey,
        nombre,
        cantidad
      });
    });
  });

  return { detalle, totalDocs: docsVistos.size };
}
