import { crearFechas } from "./utils.js";

function asegurarRow(mapa, item) {
  const key = item.codigoKey || String(item.nombre || "").toLowerCase();

  if (!mapa.has(key)) {
    mapa.set(key, {
      codigo: item.codigo,
      codigoKey: item.codigoKey,
      nombre: item.nombre,
      salidaAnterior: 0,
      salidasPorFecha: {},
      totalSemana: 0,
      totalAcumulado: 0
    });
  }

  const row = mapa.get(key);
  if (!row.codigo && item.codigo) row.codigo = item.codigo;
  if (!row.nombre && item.nombre) row.nombre = item.nombre;
  return row;
}

export function construirPivotSalidas({ detalleAnterior = [], detalleSemana = [], inicioSemana, finSemana }) {
  const mapa = new Map();
  const fechasColumnas = crearFechas(inicioSemana, finSemana);

  detalleAnterior.forEach((item) => {
    const row = asegurarRow(mapa, item);
    row.salidaAnterior += Number(item.cantidad || 0);
  });

  detalleSemana.forEach((item) => {
    const row = asegurarRow(mapa, item);
    const cantidad = Number(item.cantidad || 0);
    row.salidasPorFecha[item.fecha] = Number(row.salidasPorFecha[item.fecha] || 0) + cantidad;
    row.totalSemana += cantidad;
  });

  mapa.forEach((row) => {
    row.totalAcumulado = Number(row.salidaAnterior || 0) + Number(row.totalSemana || 0);
  });

  const registrosPivot = Array.from(mapa.values())
    .filter((r) => Number(r.totalAcumulado || 0) !== 0)
    .sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), "es"));

  return { registrosPivot, fechasColumnas };
}
