import { query, where, orderBy, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { REF_SALIDAS_ZAPATA } from "./firestoreRefs.js";
import { FECHA_INICIO_MINIMA } from "./appConfig.js";
import { normalizarCodigo, normalizarFecha } from "./utils.js";

export async function consultarSalidas(inicio, fin) {
  if (fin < inicio) return { detalle: [], totalDocs: 0 };

  const q = query(
    REF_SALIDAS_ZAPATA,
    where("fecha", ">=", inicio),
    where("fecha", "<=", fin),
    orderBy("fecha", "desc")
  );

  const snap = await getDocs(q);
  const detalle = [];
  const docsVistos = new Set();

  snap.forEach((documento) => {
    const data = documento.data() || {};
    docsVistos.add(documento.id);

    const fecha = normalizarFecha(data.fecha || data.timestamp || "");
    if (!fecha || fecha < FECHA_INICIO_MINIMA) return;

    const articulos = Array.isArray(data.articulos) ? data.articulos : [];

    articulos.forEach((art, idx) => {
      const codigoOriginal = String(art.codigo ?? "").trim();
      const codigoKey = normalizarCodigo(codigoOriginal);
      const nombre = String(art.nombre ?? "").trim();
      const cantidad = Number(art.cantidad || 0);

      if (!codigoKey && !nombre && !cantidad) return;

      detalle.push({
        tipo: "SALIDA",
        docId: documento.id,
        partida: idx + 1,
        folio: String(data.folio || documento.id || "").trim(),
        fecha,
        hora: String(data.hora || data.hora_movimiento || "00:00").trim(),
        destino: String(data.destino || "").trim(),
        entrega: String(data.entrega || "").trim(),
        recibe: String(data.recibe || "").trim(),
        folioCincho: String(data.folioCincho || "").trim(),
        proveedor: "",
        alias_pivot: "",
        rfc_emisor: "",
        razon_social_emisor: "",
        codigo: codigoOriginal,
        codigoKey,
        nombre,
        cantidad
      });
    });
  });

  return { detalle, totalDocs: docsVistos.size };
}
