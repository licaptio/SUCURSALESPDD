export const FECHA_BASE_CONSULTA = "2026-06-01";
export const NOMBRE_APP = "LISTACIGARRO";
export const IDB_NAME = "PROVSOFT_LISTACIGARRO";
export const IDB_VERSION = 2;
export const STORE_SALIDAS = "salidas";
export const STORE_META = "meta";
export const META_ULTIMA_FECHA = "ultimaFechaConsultada";
